# AutoWorld Website

Simple automotive-themed website project for GitHub.

## Features
- Homepage
- Featured cars section
- Clean dark theme

## How to run
Open index.html in your browser.
